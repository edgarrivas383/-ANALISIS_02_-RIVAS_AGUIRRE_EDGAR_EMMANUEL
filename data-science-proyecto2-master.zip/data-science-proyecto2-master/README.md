# Data Science - Caso práctico 2

<b> Usa la base de datos "synergy_logistics_database.csv" para completar los análisis solicitados en el PDF. </b>
